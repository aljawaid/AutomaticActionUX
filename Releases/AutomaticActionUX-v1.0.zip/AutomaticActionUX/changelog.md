# AutomaticActionUX Changelog

## v1.0

### What's Changed

_(most recent changes are listed on top):_
- Plugin Files
- Cleanup code
- Added english translations
- Added css and changelog
- Fixed ReadmeIncorrect links
- NEW: Add Readme


 [**Full Changelog**](../master/changelog.md "See changes")
